package com.wemade.metamask.configuration.persistence.transaction;

/**
 * User: Sewon Yoo (ysw@wemade.com)
 * Date: 2022. 01. 24.
 * Time: 오후 1:12
 */
public class TransactionType {
	public static final String BLOCKCHAIN = "transactionManagerBlockchainMyBatis";
}
