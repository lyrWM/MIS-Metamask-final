package com.wemade.metamask;

/**
 * User: Sewon Yoo (ysw@wemade.com)
 * Date: 2022. 01. 21.
 * Time: 오후 5:28
 */
public class BasePackage {
}
